public class Task {
    private String name;
    private String description;
    private int id;
    private TaskStatus status;


    public String getName() {
        return name;
    }

    public void setName(String nameTask) {
        this.name = nameTask;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public TaskStatus getStatus() {
        return status;
    }

    public void setStatus(TaskStatus status) {
        this.status = status;
    }


    @Override
    public String toString() {
        return "{" +
                "description='" + description + '\'' +
                ", id=" + id +
                ", status=" + status +
                ", name='" + name + '\'' +
                '}';
    }
}


