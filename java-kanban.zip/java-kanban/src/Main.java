public class Main {


    public static void main(String[] args) {

        TaskManager taskManager = new TaskManager();


        Task task1 = new Task();
        task1.setName("Задача 1");
        task1.setDescription("Описание задачи 1");
        taskManager.addTask(task1);

        Task task2 = new Task();
        task2.setName("Задача 2");
        task2.setDescription("Описание задачи 2");
        taskManager.addTask(task2);

        Epic epic1 = new Epic();
        epic1.setName("Эпик 1");
        epic1.setDescription("Описание эпика 1");
        taskManager.addEpic(epic1);

        Subtask subtask1 = new Subtask();
        subtask1.setName("Подзадача 1 для эпика 1");
        subtask1.setDescription("Описание подзадачи 1");
        subtask1.epicId = epic1.getId();
        taskManager.addSubtask(subtask1);

        Subtask subtask2 = new Subtask();
        subtask2.setName("Подзадача 2 для эпика 1");
        subtask2.setDescription("Описание подзадачи 2");
        subtask2.epicId = epic1.getId();
        taskManager.addSubtask(subtask2);

        Epic epic2 = new Epic();
        epic2.setName("Эпик 2");
        epic2.setDescription("Описание эпика 2");
        taskManager.addEpic(epic2);

        Subtask subtask3 = new Subtask();
        subtask3.setName("Подзадача 1 для эпика 2");
        subtask3.setDescription("Описание подзадачи 1");
        subtask3.epicId = epic2.getId();
        taskManager.addSubtask(subtask3);

        Task taskNew = new Task();
        taskNew.setId(task1.getId());
        taskNew.setName("Обновлена задача 1");
        taskNew.setDescription("Обнолено описание задачи 1");
        taskNew.setStatus(TaskStatus.IN_PROGRESS);

        Subtask subtaskNew = new Subtask();
        subtaskNew.setId(subtask1.getId());
        subtaskNew.epicId = epic1.getId();
        subtaskNew.setName("Обновлена подзазадача 1 для эпика 1");
        subtaskNew.setDescription("Обнолено описание подзадачи 1");
        subtaskNew.setStatus(TaskStatus.DONE);

        taskManager.updateSubtask(subtaskNew);
        System.out.println(taskManager.printAllTasks());
        System.out.println(taskManager.printAllEpics());
        System.out.println(taskManager.printAllSubtasks());



    }


}
