import java.util.ArrayList;

public class Epic extends Task {
ArrayList<Integer>subtaskIds = new ArrayList<>();


}

