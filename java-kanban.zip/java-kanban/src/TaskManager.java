import java.util.HashMap;
import java.util.ArrayList;

public class TaskManager {
    private HashMap<Integer, Task> tasks = new HashMap<>();
    private HashMap<Integer, Epic> epics = new HashMap<>();
    private HashMap<Integer, Subtask> subtasks = new HashMap<>();
    private int nextId = 1;

    public void addTask(Task task) { //добавить задачу
        task.setId(nextId++);
        tasks.put(task.getId(), task);
        task.setStatus(TaskStatus.NEW);
    }

    public void addEpic(Epic epic) { // добавить эпик
        epic.setId(nextId++);
        epics.put(epic.getId(), epic);
        epic.setStatus(TaskStatus.NEW);
    }


    public void addSubtask(Subtask subtask) { // добавить подзадачу
        subtask.setId(nextId++);
        subtasks.put(subtask.getId(), subtask);
        subtask.setStatus(TaskStatus.NEW);

        Epic epic = epics.get(subtask.epicId);
        epic.subtaskIds.add(subtask.getId());


    }

    public ArrayList<Task> printAllTasks() { // вывести список всех задач
        ArrayList<Task> tasksId = new ArrayList<>();
        for (Integer id : tasks.keySet()) {
            Task newTask = tasks.get(id);
            tasksId.add(newTask);
        }
        return tasksId;
    }

    public ArrayList<Epic> printAllEpics() { // вывести список всех эпиков
        ArrayList<Epic> epicsId = new ArrayList<>();
        for (Integer id : epics.keySet()) {
            Epic newEpic = epics.get(id);
            epicsId.add(newEpic);
        }
        return epicsId;
    }

    public ArrayList<Subtask> printAllSubtasks() { // вывести список всех подзадач
        ArrayList<Subtask> subtasksId = new ArrayList<>();
        for (Integer id : subtasks.keySet()) {
            Subtask newSubtask = subtasks.get(id);
            subtasksId.add(newSubtask);
        }
        return subtasksId;
    }

    public void removeAllTasks() {
        tasks.clear();
    } // удалить все задачи

    public void removeAllEpics() {
        epics.clear();
    } // удалить все эпики

    public void removeAllSabtasks() {
        subtasks.clear();
    } // удалить все подзадачи

    public Task getTaskById(int idTask) { // получение задачи по ID
        if (tasks.containsKey(idTask)) {
            return tasks.get(idTask);
        }
        return null;
    }

    public Epic getEpicById(int idEpic) {// получение эпика по ID
        if (epics.containsKey(idEpic)) {
            return epics.get(idEpic);
        }
        return null;
    }

    public Task getSabtaskById(int idSabtask) { // получение подзадачи по ID
        if (subtasks.containsKey(idSabtask)) {
            return subtasks.get(idSabtask);
        }
        return null;
    }

    public void updateTask(Task task) { // обновление задачи
        tasks.put(task.getId(), task);
    }

    public void updateEpic(Epic epic) { // обновление эпика
        epics.put(epic.getId(), epic);
    }

    public void updateSubtask(Subtask subtask) { // обновление подзадачи
        subtasks.put(subtask.getId(), subtask);
        Epic epic = epics.get(subtask.epicId);
        for (Integer subtaskId : epic.subtaskIds) {
            Subtask anSubtask = subtasks.get(subtaskId);
            if (anSubtask.getStatus() == TaskStatus.NEW || anSubtask.getStatus() == null) {
                epic.setStatus(anSubtask.getStatus());
            } else if (anSubtask.getStatus() == TaskStatus.DONE) {
                epic.setStatus(anSubtask.getStatus());
            } else {
                epic.setStatus(anSubtask.getStatus());
            }
        }
    }




    public void deleteTaskById(int idTask) { // удаление задачи по ID
        if (tasks.containsKey(idTask)) {
            tasks.remove(idTask);
        }
        System.out.println("Такой задачи нет");
    }

    public void deleteEpicById(int idEpic) { // удаление эпика по ID
        if (epics.containsKey(idEpic)) {
            epics.remove(idEpic);
        }
        System.out.println("Такого эпика нет");
    }

    public void deleteSubtaskById(int idSubtask) { // удаление подзадачи по ID
        if (subtasks.containsKey(idSubtask)) {
            subtasks.remove(idSubtask);
        }
        System.out.println("Такой подзадачи нет");
    }

    public ArrayList<Integer> printAllSubtasksByEpic(int idEpic) { // получение позадач конкретного эпика
        if (epics.containsKey(idEpic)) {
            Epic epic = epics.get(idEpic);
            return epic.subtaskIds;
        }
        return null;
    }



}










